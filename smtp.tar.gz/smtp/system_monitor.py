import smtplib
import subprocess
import psutil
import socket
import json
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from datetime import datetime
import pytz
import os
import time

# Load configuration from JSON file
config_file = '/opt/smtp/config.json'
if not os.path.exists(config_file):
    raise FileNotFoundError(f"Configuration file {config_file} not found")

with open(config_file, 'r') as f:
    config = json.load(f)

# SMTP Configuration from config
email_sender = config['email_sender']
email_receivers = config['email_receivers']
smtp_server = config['smtp_server']
smtp_port = config['smtp_port']
smtp_username = config['smtp_username']
smtp_password = config['smtp_password']
logo_url = 'https://oneplatform.blusapphire.com/images/logos/oneplatform-login_icon.png'

# Threshold Configuration from config
try:
    threshold_disk = float(config['threshold_disk'])
    threshold_memory = float(config['threshold_memory'])
    threshold_cpu = float(config['threshold_cpu'])
    check_interval = float(config['check_interval'])
    email_cooldown = float(config['email_cooldown'])
    # Validate thresholds and intervals
    for thresh, name in [(threshold_disk, 'threshold_disk'), (threshold_memory, 'threshold_memory'), (threshold_cpu, 'threshold_cpu')]:
        if not 0 <= thresh <= 100:
            raise ValueError(f"{name} must be between 0 and 100, got {thresh}")
    if check_interval <= 0:
        raise ValueError(f"check_interval must be positive, got {check_interval}")
    if email_cooldown <= 0:
        raise ValueError(f"email_cooldown must be positive, got {email_cooldown}")
except KeyError as e:
    raise KeyError(f"Missing required key in config.json: {e}")
except ValueError as e:
    raise ValueError(f"Invalid value in config.json: {e}")

# Time zone from config
time_zone = config['time_zone']
try:
    tz = pytz.timezone(time_zone)
except pytz.exceptions.UnknownTimeZoneError:
    raise ValueError(f"Invalid time zone specified in config: {time_zone}")

# Email subject with dynamic hostname
email_subject = f'System Resource Alert for {socket.gethostname()}'

# Track last email sent time
last_email_time = None

def get_disk_usage():
    """Return the disk usage percentage of the root filesystem."""
    disk_usage = psutil.disk_usage('/')
    return disk_usage.percent

def get_memory_usage():
    """Return memory usage details."""
    memory_info = psutil.virtual_memory()
    return memory_info.total, memory_info.available, memory_info.used, memory_info.percent

def get_cpu_usage():
    """Return CPU usage details and average usage across all cores."""
    cpu_percentages = psutil.cpu_percent(percpu=True)
    avg_cpu_usage = sum(cpu_percentages) / len(cpu_percentages) if cpu_percentages else 0
    return cpu_percentages, avg_cpu_usage

def get_df_output():
    """Run 'df -h' command and return its output."""
    result = subprocess.run(['df', '-h'], capture_output=True, text=True)
    return result.stdout

def format_cpu_usage(cpu_percentages):
    """Format CPU usage as HTML table rows."""
    rows = ""
    for i, percent in enumerate(cpu_percentages):
        rows += f"""
        <tr>
            <td>CPU Core {i}</td>
            <td>{percent}%</td>
        </tr>
        """
    return rows

def format_memory_usage(total, available, used, percent):
    """Format memory usage as HTML table row."""
    return f"""
    <tr>
        <td>{format_size(total)}</td>
        <td>{format_size(available)}</td>
        <td>{format_size(used)}</td>
        <td>{percent}%</td>
    </tr>
    """

def format_df_output(df_output):
    """Format df -h output as HTML table rows."""
    lines = df_output.splitlines()
    html_rows = ""
    
    for line in lines[1:]:
        columns = line.split()
        if columns:
            html_rows += "<tr>"
            for column in columns:
                html_rows += f"<td>{column}</td>"
            html_rows += "</tr>"
    
    return html_rows

def format_size(bytes_size):
    """Format size in human-readable format."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} TB"

def send_email(subject, body):
    """Send an email with the given subject and body."""
    global last_email_time
    msg = MIMEMultipart()
    msg['From'] = email_sender
    msg['Subject'] = subject
    
    # Attach the body with HTML content
    msg.attach(MIMEText(body, 'html'))
    
    # Fetch and attach the logo image from URL
    try:
        response = requests.get(logo_url, timeout=10)
        response.raise_for_status()  # Raise an exception for bad status codes
        logo = MIMEImage(response.content)
        logo.add_header('Content-ID', '<logo.png>')
        msg.attach(logo)
    except requests.RequestException as e:
        print(f"Failed to fetch logo from {logo_url}: {e}")
        # Continue without logo if fetching fails
        pass
    
    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_username, smtp_password)
            
            for receiver in email_receivers:
                server.sendmail(email_sender, receiver, msg.as_string())
        
        print("Email sent successfully to all recipients!")
        last_email_time = time.time()  # Update last email time
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False

def main():
    """Check system resource usage periodically and send alert emails if thresholds are exceeded."""
    global last_email_time
    while True:
        # Get current time in configured time zone
        current_time = datetime.now(tz).strftime('%I:%M %p %Z on %A, %B %d, %Y')

        disk_usage = get_disk_usage()
        memory_total, memory_available, memory_used, memory_percent = get_memory_usage()
        cpu_percentages, avg_cpu_usage = get_cpu_usage()

        alert_message = []
        include_cpu_usage = False
        include_memory_usage = False
        include_disk_usage = False
        
        # Check thresholds and build alert messages
        if avg_cpu_usage > threshold_cpu:
            alert_message.append(f"CPU usage is high: {avg_cpu_usage:.1f}% (average across all cores)")
            include_cpu_usage = True

        if memory_percent > threshold_memory:
            alert_message.append(f"Memory usage is high: {memory_percent}%")
            include_memory_usage = True

        if disk_usage > threshold_disk:
            alert_message.append(f"Disk usage is high: {disk_usage}%")
            include_disk_usage = True

        # If no thresholds exceeded, print message and continue
        if not alert_message:
            print(f"No alerts triggered at {current_time}. Checking again in {check_interval} seconds.")
        else:
            # Check if enough time has passed since the last email
            current_time_seconds = time.time()
            if last_email_time is None or (current_time_seconds - last_email_time) >= email_cooldown:
                # Read the HTML template
                with open('/opt/smtp/source.html', 'r') as file:
                    html_template = file.read()

                # Format data for tables that need to be included
                cpu_html_rows = format_cpu_usage(cpu_percentages) if include_cpu_usage else ""
                memory_html_row = format_memory_usage(memory_total, memory_available, memory_used, memory_percent) if include_memory_usage else ""
                df_html_rows = format_df_output(get_df_output()) if include_disk_usage else ""

                # Remove sections from HTML template if not needed
                email_body = html_template
                if not include_cpu_usage:
                    email_body = email_body.replace(
                        "<!-- CPU Usage Table -->\n    <h3>CPU Usage</h3>\n    <table>\n        <tr>\n            <th>CPU Core</th>\n            <th>Usage %</th>\n        </tr>\n        <!-- Data rows for CPU usage will be inserted here -->\n    </table>",
                        ""
                    )
                if not include_memory_usage:
                    email_body = email_body.replace(
                        "<!-- Memory Usage Table -->\n    <h3>Memory Usage</h3>\n    <table>\n        <tr>\n            <th>Total</th>\n            <th>Available</th>\n            <th>Used</th>\n            <th>Percentage Used</th>\n        </tr>\n        <!-- Data rows for memory usage will be inserted here -->\n    </table>",
                        ""
                    )
                if not include_disk_usage:
                    email_body = email_body.replace(
                        "<!-- Disk Usage Table -->\n    <h3>Disk Usage</h3>\n    <table>\n        <tr>\n            <th>Filesystem</th>\n            <th>Size</th>\n            <th>Used</th>\n            <th>Avail</th>\n            <th>Use%</th>\n            <th>Mounted on</th>\n        </tr>\n        <!-- Data rows for disk usage will be inserted here -->\n    </table>",
                        ""
                    )

                # Insert the formatted table rows
                email_body = email_body.replace("<!-- Data rows for CPU usage will be inserted here -->", cpu_html_rows)
                email_body = email_body.replace("<!-- Data rows for memory usage will be inserted here -->", memory_html_row)
                email_body = email_body.replace("<!-- Data rows for disk usage will be inserted here -->", df_html_rows)

                # Add alert messages and sending time
                email_body = f"""
                <h2>System Resource Report</h2>
                <p>Sending time: {current_time}</p>
                <h3>System Alerts</h3>
                <p>{"<br>".join(alert_message)}</p><br>
                {email_body}
                """

                # Send the email
                send_email(email_subject, email_body)
            else:
                print(f"Alerts triggered at {current_time}, but email skipped due to cooldown. Next email possible in {int(email_cooldown - (current_time_seconds - last_email_time))} seconds.")

        # Wait before the next check
        time.sleep(check_interval)

if __name__ == "__main__":
    main()
